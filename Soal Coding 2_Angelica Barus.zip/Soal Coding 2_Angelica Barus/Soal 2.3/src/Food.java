public class Food extends Product {

    public Food(String name, double price, int quantity) {
        super(name, price, quantity);
    }

    @Override
    public double getTotalPrice() {
        return calculateTotal();
    }
}

