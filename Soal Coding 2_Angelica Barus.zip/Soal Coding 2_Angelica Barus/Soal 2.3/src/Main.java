public class Main {
    public static void main(String[] args) {
        Product[] items = {
            new Food("Nasi Goreng", 15000, 2),
            new Food("Mie Ayam", 12000, 1),
            new Food("Sate Ayam", 20000, 3),
            new Food("Bakso", 15000, 2),
            new Food("Gado Gado", 13000, 1),

            new Beverage("Es Teh", 10000, 3),
            new Beverage("Kopi Hitam", 10000, 2),
            new Beverage("Jus Jeruk", 12000, 1),
            new Beverage("Susu Cokelat", 15000, 2),
            new Beverage("Pop Ice", 10000, 5)
        };

        double grandTotal = 0;
        System.out.println("\033[1mNota Pembelian\033[0m");
        System.out.printf("%-15s |%-16s | %-9s | %-10s%n", "Nama", "Harga", "Jumlah", "Total");
        System.out.println("-------------------------------------------------------------------");

        for (Product item : items) {
            item.display();
            grandTotal += item.getTotalPrice();
        }

        System.out.println("------------------------------------------------------------------");
        System.out.printf("%-23s | %-10s      | %-8s  | %-10.2f%n","\033[1mTotal\033[0m", "", "", grandTotal);
        System.out.println("==================================================================");
    }
}
