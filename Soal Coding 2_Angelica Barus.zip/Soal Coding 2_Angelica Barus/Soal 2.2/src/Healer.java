public class Healer extends Character implements SkillHealing {

    public Healer(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        System.out.println(name + " tidak menyerang secara langsung.");
    }

    @Override
    public void healAlly() {
        System.out.println(name + " menyembuhkan sekutu dengan energi suci.");
    }
}
