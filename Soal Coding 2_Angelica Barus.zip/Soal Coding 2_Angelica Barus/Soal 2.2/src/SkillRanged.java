public interface SkillRanged {
     void rangedAttack();
}
