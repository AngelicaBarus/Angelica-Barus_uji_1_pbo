public interface SkillMagic {
    void castSpell();
}

