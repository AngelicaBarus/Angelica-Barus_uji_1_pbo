public final class Queen extends RoleEksklusif {

    public Queen(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        System.out.println(name + " melancarkan serangan sihir kerajaan!");
    }

    public void inspire() {
        System.out.println(name + " menginspirasi pasukan dengan kata-katanya.");
    }
}

