public class Rogue extends Character implements SkillPhysical, SkillStealth {

    public Rogue(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        physicalAttack();
    }

    @Override
    public void physicalAttack() {
        System.out.println(name + " menyerang dari bayangan dengan serangan tajam!");
    }

    @Override
    public void stealthMove() {
        System.out.println(name + " bergerak tanpa terlihat oleh musuh.");
    }
}

