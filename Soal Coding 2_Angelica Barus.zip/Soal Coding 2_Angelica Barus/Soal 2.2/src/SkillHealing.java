public interface SkillHealing {
    void healAlly();
}

