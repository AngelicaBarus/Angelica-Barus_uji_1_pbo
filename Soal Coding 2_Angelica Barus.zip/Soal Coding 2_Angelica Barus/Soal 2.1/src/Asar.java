public class Asar extends Prayer implements AudioReminder {

    public Asar(String jam) {
        super(jam);
    }

    @Override
    public void remind() {
        System.out.println("* Waktu menunjukkan pukul " + jam + ". Saatnya sholat Asar!");
    }

    @Override
    public void playAdzan(){}
}
