public class Fajr extends Prayer implements AudioReminder {

    public Fajr(String jam) {
        super(jam);
    }

    @Override
    public void remind() {
        System.out.println("* Waktu menunjukkan pukul" + jam + ". Saatnya sholat Fajr");
    }

    @Override
    public void playAdzan(){}
}
