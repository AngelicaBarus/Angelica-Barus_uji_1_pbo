public abstract class Prayer {
    protected String jam;

    public Prayer(String jam) {
        this.jam = jam;
    }

    public abstract void remind();
}

