class Car extends Vehicle implements Electric {
    @Override
    public void startEngine() {
        System.out.println("\033[1mVechile Operations\033[0m");
        System.out.println("(1) Type  : Car");
        System.out.println("    Action: Starting Vehicle Engine");
        System.out.println("    Status: The car has been successfully started!");
    }

    @Override
    public void chargeBattery() {
        System.out.println("(3) Type  : Electric Car");
        System.out.println("    Action: Charging Battery");
        System.out.println("    Status: The electric car battery is now charging!");
    }
}
