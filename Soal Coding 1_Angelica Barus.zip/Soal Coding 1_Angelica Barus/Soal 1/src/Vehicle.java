public abstract class Vehicle {
    public abstract void startEngine();
}
