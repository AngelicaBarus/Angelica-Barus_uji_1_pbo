public interface Electric {
    void chargeBattery();
}
