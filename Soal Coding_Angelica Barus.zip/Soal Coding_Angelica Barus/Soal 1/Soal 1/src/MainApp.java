public class MainApp {
    public static void main(String[] args) {
        Vehicle myCar = new Car();
        Vehicle myMotorcycle = new Motorcycle();

        myCar.startEngine();

        myMotorcycle.startEngine();

        if (myCar instanceof Electric) {
            Electric electricCar = (Electric) myCar;
            electricCar.chargeBattery();
        }
    }
}

