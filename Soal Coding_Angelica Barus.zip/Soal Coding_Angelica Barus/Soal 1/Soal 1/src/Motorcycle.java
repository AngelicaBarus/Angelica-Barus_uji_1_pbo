public class Motorcycle extends Vehicle {
    @Override
    public void startEngine() {
        System.out.println("(2) Type  : Motorcycle");
        System.out.println("    Action: Starting Vehicle Engine");
        System.out.println("    Status: The motorcycle has been successfully started!");
    }
}
