public class Warrior extends Character implements SkillPhysical {

    public Warrior(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        physicalAttack();
    }

    @Override
    public void physicalAttack() {
        System.out.println(name + " melakukan serangan fisik dengan pedang!");
    }
}

