public class Mage extends Character implements SkillMagic {

    public Mage(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        castSpell();
    }

    @Override
    public void castSpell() {
        System.out.println(name + " melemparkan mantra api!");
    }
}

