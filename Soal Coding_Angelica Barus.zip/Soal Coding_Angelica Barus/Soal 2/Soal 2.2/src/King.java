public final class King extends RoleEksklusif {

    public King(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        System.out.println(name + " menggunakan serangan kerajaan yang dahsyat!");
    }

    public void rule() {
        System.out.println(name + " memimpin kerajaan dengan bijaksana.");
    }
}
