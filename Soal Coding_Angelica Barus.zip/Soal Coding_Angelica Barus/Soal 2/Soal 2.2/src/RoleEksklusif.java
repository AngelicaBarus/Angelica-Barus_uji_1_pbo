public sealed class RoleEksklusif extends Character permits King, Queen {

    public RoleEksklusif(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        System.out.println(name + " menyerang dengan kekuatan eksklusifnya!");
    }
}

