public interface SkillPhysical {
    void physicalAttack();
}

