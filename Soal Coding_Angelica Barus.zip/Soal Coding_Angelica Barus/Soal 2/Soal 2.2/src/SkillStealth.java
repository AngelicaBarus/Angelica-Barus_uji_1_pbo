public interface SkillStealth {
    void stealthMove();
}
