public class Main {

    public static void main(String[] args) {
        Character[] characters = {
            new Warrior("Arthas", 19),
            new Mage("Jaina", 20),
            new Archer("Sylvanas", 21),
            new Healer("Uther", 22),
            new Rogue("Valeera", 23),
            new King("Terenas", 25),
            new Queen("Meryl", 24)
        };

        System.out.println("=== SYSTEM KARAKTER RPG ===\n");

        for (int i = 0; i < characters.length; i++) {
            Character character = characters[i];

            System.out.println("Karakter\t: " + (i + 1));
            System.out.println("Nama\t\t: " + character.name);
            System.out.println("Level\t\t: " + character.level);
            System.out.println("Tipe\t\t: " + character.getClass().getSimpleName());

            System.out.print("Serangan utama\t: ");
            character.attack();

            if (character instanceof SkillPhysical) {
                System.out.print("Skill Fisik\t: ");
                ((SkillPhysical) character).physicalAttack();
            }
            if (character instanceof SkillMagic) {
                System.out.print("Skill Magis\t: ");
                ((SkillMagic) character).castSpell();
            }
            if (character instanceof SkillHealing) {
                System.out.print("Skill Penyembuhan\t: ");
                ((SkillHealing) character).healAlly();
            }
            if (character instanceof SkillStealth) {
                System.out.print("Skill Siluman\t: ");
                ((SkillStealth) character).stealthMove();
            }
            if (character instanceof SkillRanged) {
                System.out.print("Skill Jarak Jauh\t: ");
                ((SkillRanged) character).rangedAttack();
            }
            if (character instanceof King) {
                System.out.print("Peran Khusus\t: ");
                ((King) character).rule();
            }
            if (character instanceof Queen) {
                System.out.print("Peran Khusus\t: ");
                ((Queen) character).inspire();
            }

            System.out.println("\n--------------------------------------------------------------------\n");
        }
    }
}
