public class Archer extends Character implements SkillRanged, SkillStealth {

    public Archer(String name, int level) {
        super(name, level);
    }

    @Override
    public void attack() {
        rangedAttack();
    }

    @Override
    public void rangedAttack() {
        System.out.println(name + " menyerang dengan panah dari kejauhan!");
    }

    @Override
    public void stealthMove() {
        System.out.println(name + " berdiam diri dan bergerak secara diam-diam.");
    }
}

