public class Isya extends Prayer implements AudioReminder {

    public Isya(String jam) {
        super(jam);
    }

    @Override
    public void remind() {
        System.out.println("* Waktu Menunjukkan Pukul " + jam + ". Saatnya sholar Isya!");
    }

    @Override
    public void playAdzan(){}
}

