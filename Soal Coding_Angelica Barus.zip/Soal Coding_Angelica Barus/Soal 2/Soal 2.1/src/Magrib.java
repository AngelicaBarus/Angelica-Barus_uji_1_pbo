public class Magrib extends Prayer implements AudioReminder {

    public Magrib(String jam) {
        super(jam);
    }

    @Override
    public void remind() {
        System.out.println("* Waktu Menunjukkan Pukul " + jam + ". Saatnya sholat Magrib!");
    }

   @Override
    public void playAdzan(){}
}
