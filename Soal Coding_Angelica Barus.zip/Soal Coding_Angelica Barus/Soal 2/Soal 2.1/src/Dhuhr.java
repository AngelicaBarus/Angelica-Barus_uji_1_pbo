public class Dhuhr extends Prayer implements AudioReminder {

    public Dhuhr(String jam) {
        super(jam);
    }

    @Override
    public void remind() {
        System.out.println("* Waktu Menunjukkan Pukul" + jam + ". Saatnya Sholat Dhuhr!");
    }

    @Override
    public void playAdzan(){}
}
