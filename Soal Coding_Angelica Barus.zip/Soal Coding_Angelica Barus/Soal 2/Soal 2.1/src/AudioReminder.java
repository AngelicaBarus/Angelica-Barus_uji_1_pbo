public interface AudioReminder {
    void playAdzan();
}
