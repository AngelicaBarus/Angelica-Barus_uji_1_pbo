public class Main {
    public static void main(String[] args) {
        Prayer[] prayers = {
            new Fajr("04:50 AM"),
            new Dhuhr("12:22 PM"),
            new Asar("15:47 PM"),
            new Magrib("18:31 PM"),
            new Isya("19:46 PM")
        };

        System.out.println("\033[1mJadwal Sholat\033[0m");

        for (int i = 0; i < prayers.length; i++) {
            Prayer prayer = prayers[i];
            System.out.println((i + 1) + ". Sholat: " + prayer.getClass().getSimpleName());
            System.out.println("   Waktu: " + prayer.jam);
            prayer.remind();

            if (prayer instanceof AudioReminder) {
                ((AudioReminder) prayer).playAdzan();
            } else {
                System.out.println("   Tindakan: Belum Waktunya Solat");
            }
        }
    }
}
