public class Beverage extends Product implements Taxable {

    private static final double TAX_RATE = 0.1;

    public Beverage(String name, double price, int quantity) {
        super(name, price, quantity);
    }

    @Override
    public double calculateTax() {
        return calculateTotal() * TAX_RATE;
    }

    @Override
    public double getTotalPrice() {
        return calculateTotal() + calculateTax();
    }
}

